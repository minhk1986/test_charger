#include "ros/ros.h"
#include "std_msgs/String.h"
#include <geometry_msgs/Twist.h>
#include <linefolowing/MLS_Measurement.h>
#include <linefolowing/speed_wheel.h> 
#include <agv_define/agv_action.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <pthread.h>

#include <actionlib/server/simple_action_server.h>
#include <agv_define/lineAction.h>  // Note: "Action" is appended

typedef actionlib::SimpleActionServer<agv_define::lineAction> Server;

#define DEFAULT_DIRECTION "forward" 

#define LCP_NUM_BIT   	       0b00000111
#define MAKER_NUM_BIT 	       0b11111000
#define LINE_IS_GOOD_BIT       0b00000001
#define TRACK_LEVEL_BIT        0b00001110
#define SENSOR_FLIPPED_BIT     0b00010000
#define POLARITY_BIT 	       0b00100000
#define READING_CODE_BIT       0b01000000
#define EVENT_FLAG_BIT         0b10000000

struct lcp
{
	uint8_t lcp_nummber;
	uint8_t marker;
};  lcp lcp;

struct status
{
	bool line_good;
	bool sensor_fipped;
	bool polarity;
	bool reading_code;
	uint8_t track_level;
};  status status;

struct mlse
{
	uint8_t status;
	uint8_t lcp;
	uint8_t error_register;	
	float position[3];
};  mlse mlse;
 
enum State {
	STATE_EXECUTE,
	STATE_CANCEL
};

/* Include funtion for Sick line */
void Gacceleration(float& present_speed, const float step);
void Deceleration(float& present_speed, const float step);
geometry_msgs::Twist wheelToCmdVel (int8_t dir, int32_t speed_left, int32_t speed_right);
bool loadParam(std::string node_name);
void stopRobot();
void line_backward(Server* as);
void line_forward(Server* as);

#define Pi 3.1415926535
#define rad_rpm 9.5492965964254

//Global data
float present_speed;  		 			 // percent speed %
float present_speed_setting; 	         // percent speed setting
float speed_setting; 					 // speed max when percent speed = 100%  (m/s)
float Lm; 								 // Khoang cach  tu tam truc banh den tam do line 
float Lt;								 // Dường kính vòng cua
float V;  						  		 // forward velocity (ie meters per second)
int W_l, W_r; 				   	     	 // speed befor gear
int8_t direct ;

std::string topic;
float L, R, K;
float BLVD20KM_SPEED_MIN, BLVD20KM_SPEED_MAX, BLVD20KM_TORQUE_MAX;
float position_0, position_1, position_2;

geometry_msgs::Twist cmd_vel;
linefolowing::speed_wheel robot;

std::string direct_;
uint8_t state_ = 0;
bool isEnable = true;
ros::Publisher cmd_vel_pub;

void lineActionCallback(const agv_define::lineGoalConstPtr& goal, Server* as)
{
	ROS_INFO("linefolowersick.cpp-80-lineActionCallback()");
	direct_ = goal->direct;
	state_ = State(goal->state);
	ROS_INFO("linefolowersick.cpp-158-direct_: %s", direct_.c_str());
	ROS_INFO("linefolowersick.cpp-159-state_: %d", state_);
	if(direct_ == "LINE_IN"){
	  	direct = -1;
		if(state_ == STATE_EXECUTE){
			isEnable = true;
			line_backward(as);
		}else if(state_ == STATE_CANCEL){
			isEnable = false;		
			stopRobot();
		}
	}else if(direct_ == "LINE_OUT"){
	  	direct = 1;
		if(state_ == STATE_EXECUTE){
			isEnable = true;
			line_forward(as);
		}else if(state_ == STATE_CANCEL){
			isEnable = false;		
			stopRobot();
		}
	}
}//teleop_keyCallback 

void stopRobot(){
	robot.wheel_letf = 0;
	robot.wheel_right = 0;
	cmd_vel = wheelToCmdVel(direct, robot.wheel_letf, robot.wheel_right);
	cmd_vel_pub.publish(cmd_vel);
}

void line_backward(Server* as){
	ROS_INFO("linefolowersick.cpp-152-line_backward()");
	/* clock */
	clock_t begin_time = clock();
	ros::Rate loop_rate(20);

	linefolowing::speed_wheel robot;
	while ((ros::ok()) && (isEnable==true))
	{
		float angle_error; 	        // error angle 
		float W;  					// angular velocity (ie radians per second)
		float v_r; 					// clockwise angular velocity of right wheel (ie radians per second)
		float v_l;				 	// counter-clockwise angular velocity of left wheel (ie radians per second)

		if(status.line_good == true && int8_t(speed_setting/abs(speed_setting)) == direct){
			if(position_2 > 0.00){	
				if(position_0 != 0.00 && position_1 != 0.00){
					present_speed_setting = 0;
					direct = 0;

					isEnable = false;
					stopRobot();
					as->setSucceeded();
				}			
			}else if(position_2 <= 0.00) {
				if(position_0 == 0.00) {
					present_speed_setting = 1;
					ROS_INFO("linefolwersick.cpp-179: Vung 1, run, dir = %d", direct);	
					for(int i = 0; i<0; i++) ROS_INFO(" ");
				} else if(position_0 < 0.00) {
					present_speed_setting = 0.32;
					ROS_INFO("linefolwersick.cpp-185: Vung 0, giam toc, dir = %d", direct);	 	
					for(int i = 0; i<0; i++) ROS_INFO(" ");
				}
			}
		}else present_speed_setting = 0;

		V = abs(speed_setting*present_speed); // V cai dat 
		angle_error = atan(position_1/Lm);
		v_l = ((1 - (L*angle_error)/(2*Lt)) * (V/R)) * rad_rpm;
		v_r = ((1 + (L*angle_error)/(2*Lt)) * (V/R)) * rad_rpm;
		
		W_l = v_l*K;
		if(W_l > BLVD20KM_SPEED_MAX) W_l = BLVD20KM_SPEED_MAX;
		if(W_l < BLVD20KM_SPEED_MIN) W_l = 0;

		W_r = v_r*K;
		if(W_r > BLVD20KM_SPEED_MAX) W_r = BLVD20KM_SPEED_MAX;
		if(W_r < BLVD20KM_SPEED_MIN) W_r = 0;


		/* This is a message object. You stuff it with data, and then publish it. */
		if(int8_t(speed_setting/abs(speed_setting)) ==  direct) {
			if(float(clock()-begin_time)/CLOCKS_PER_SEC*1000  >= 1) {
				if(present_speed != present_speed_setting) {
					if(present_speed_setting > present_speed) {
						Gacceleration(present_speed, 0.02);
					}else if(present_speed_setting < present_speed) {
						Deceleration(present_speed, 0.02);
					}
				} 
				begin_time = clock();
			}
			if(status.line_good == true){
				robot.wheel_letf  = W_l*direct;
				robot.wheel_right = W_r*direct*(-1);
				if(status.track_level <= 3 && status.track_level > 0) {
					ROS_WARN("linefolowersick.cpp-310-From MLS: track too weak!!");
				}
			}else {
				ROS_ERROR("linefolowersick.cpp-313-From MLS: no track!!");
				robot.wheel_letf = 0;
				robot.wheel_right = 0;
				isEnable = false;
				as->setAborted(agv_define::lineResult(), "From MLS: no track!!");
			}
			ROS_INFO("linefolowersick.cpp-317- Banh trai = %d Banh phai = %d", robot.wheel_letf, robot.wheel_right);
			cmd_vel = wheelToCmdVel(direct, robot.wheel_letf, robot.wheel_right);
			cmd_vel_pub.publish(cmd_vel);
		}
		loop_rate.sleep();
		ros::spinOnce();
	}
}
void line_forward(Server* as){}

void mlsCallback(const linefolowing::MLS_Measurement& msg)
{
	// ROS_INFO("linefolowersick.cpp-252-mlsCallback()");
	mlse.status = msg.status;
	mlse.lcp = msg.lcp;
	/* 
	* #LCP
	* The following assignment applies (see "Outputof line center points", page 40):
	* 0 => No track found
	* 2 => One track found
	* 3 => Two tracks found: Left diverter
	* 6 => Two tracks found: Left diverter
	* 7 => Three tracks found or 90 °C intersection
	*/
	lcp.lcp_nummber = mlse.lcp & LCP_NUM_BIT;
	/* 
	* Marker 
	* Bit 0 is the introductory character bit
	* Bit 1...4 present code 1...15
	*/
	lcp.marker = mlse.lcp & MAKER_NUM_BIT;
	/* 
	* True is  Sufficiently strong track detected
	* Fasle is  No track or track too weak
	*/
	status.line_good = mlse.status & LINE_IS_GOOD_BIT;
	/*
	* Display of magnetic field strength in accor‐dance
	*/
	status.track_level = mlse.status & TRACK_LEVEL_BIT;
	/*
	* Indicates whether or not the measuring rangehas been inverted
	* False => Negative positions on cable outlet side
	* True => Positive positions on cable outlet side
	*/
	status.sensor_fipped = mlse.status & SENSOR_FLIPPED_BIT;
	/*
	* Indicates whether the upper surface of themagnetic tape is magnetized to the north orsouth pole
	* False => North pole
	* True => South pole
	*/
	status.polarity = mlse.status & POLARITY_BIT;
	/* 
	* False => No code present to read
	* True => Sensor is reading code
	*/
	status.reading_code = mlse.status & READING_CODE_BIT;
	/* Error register */
	mlse.error_register = msg.error;

	position_0 = msg.position[0];
	position_1 = msg.position[1];
	position_2 = msg.position[2];
} //echo_line_previousCallback

geometry_msgs::Twist wheelToCmdVel (int8_t dir, int32_t speed_left, int32_t speed_right)
{
	geometry_msgs::Twist cmd_vel;

	// ROS_INFO("linefolowersick.cpp-216- Ti so truyen: K = %d", K);
	// ROS_INFO("linefolowersick.cpp-217- Ban kinh banh xe: R = %f", R);
	// ROS_INFO("linefolowersick.cpp-218- Khoang cach giua 2 banh xe: L = %f", L);
	// ROS_INFO("linefolowersick.cpp-219- rad_rpm = %f", rad_rpm);

	float linear  = (R * (abs(speed_left) + abs(speed_right)))/(2 * K * rad_rpm);
	float angular = (R * (abs(speed_left) - abs(speed_right)))/(L * K * rad_rpm);
	if(dir == -1){
		cmd_vel.linear.x  = -linear;
		cmd_vel.angular.z = angular;
	}
	ROS_INFO("linefolowersick.cpp-317-linear = %f, angular = %f", cmd_vel.linear.x, cmd_vel.angular.z);
  
  	return cmd_vel;
}

bool loadParam(std::string node_name){
  ROS_INFO("linefolowersick.cpp-loadParam() - node_name: %s", node_name.c_str());

  if(!ros::param::get(node_name + "/L", L)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- L: %0.3f", L);
  if(!ros::param::get(node_name + "/R", R)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- R: %0.3f", R);
  if(!ros::param::get(node_name + "/K", K)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- K: %0.0f", K);
    if(!ros::param::get(node_name + "/BLVD20KM_SPEED_MIN", BLVD20KM_SPEED_MIN)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- BLVD20KM_SPEED_MIN: %0.0f", BLVD20KM_SPEED_MIN);
  if(!ros::param::get(node_name + "/BLVD20KM_SPEED_MAX", BLVD20KM_SPEED_MAX)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- BLVD20KM_SPEED_MAX: %0.0f", BLVD20KM_SPEED_MAX);
  if(!ros::param::get(node_name + "/BLVD20KM_TORQUE_MAX", BLVD20KM_TORQUE_MAX)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- BLVD20KM_TORQUE_MAX: %0.0f", BLVD20KM_TORQUE_MAX);
  if(!ros::param::get(node_name + "/present_speed_setting", present_speed_setting)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- present_speed_setting: %f", present_speed_setting);

  if(!ros::param::get(node_name + "/Lm", Lm)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- Lm: %0.3f", Lm);
  if(!ros::param::get(node_name + "/Lt", Lt)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- Lt: %0.3f", Lt);
  if(!ros::param::get(node_name + "/speed", speed_setting)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- speed_setting: %0.3f", speed_setting);
  if(!ros::param::get(node_name + "/topic", topic)){
    return false;
  }
  ROS_INFO("linefolowersick.cpp- topic: %s", topic.c_str());

  return true;
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "linefolowersick");
	ros::NodeHandle n;
	
	std::string node_name = ros::this_node::getName();
	ROS_INFO("linefolowersick.cpp-node_name: %s", node_name.c_str());
	if(loadParam(node_name)){
		ROS_INFO("linefolowersick.cpp-Load parameter successfull");
	}else{
		ROS_ERROR("linefolowersick.cpp-Error when load parameter");
	}

	/* Publisher */
	cmd_vel_pub = n.advertise<geometry_msgs::Twist>("cmd_vel", 20);
	
	Server server(n, "line_action", boost::bind(&lineActionCallback, _1, &server), false);
  	server.start();
	 
	/* Subscriber position line */ 	
	ros::Subscriber mls = n.subscribe(topic, 20, mlsCallback);
	
  	ros::spin();
	return 0;
}

void Gacceleration(float& present_speed,const float step)
{
	present_speed += step;
}

void Deceleration(float& present_speed, const float step)
{
	present_speed -= step;
}

